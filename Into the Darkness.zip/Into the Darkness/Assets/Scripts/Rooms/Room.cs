﻿/* Made by: Christopher Ansbach
 * Last Modified: 5/2/2019
 * Purpose: This is the Room scriptable object.
 */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Text/Room")]

public class Room : ScriptableObject
{
    public List<string> items;                      //Items in the room
    public List<Enemy> monsters;                    //Monsters in the room
    public bool startWMonster;                      //Determine if the room should start with monsters
    public int index;                               //Index of the room
    public string roomName;                         //Name of the room
    public bool isTrapped;                          //Determine if the room is trapped
    public bool hasMonster;                         //Determine if the room has a monster in it
    public bool newMonster;                         //Determine if the room was given a new monster
    [TextArea] public string description;           //Description of the room
    public Exit[] exits;                            //Exits in the room
    public Stairs[] stairs;                         //Stairs in the room
    public bool bossRoom;                           //Determine if the boss is the boss room
}
