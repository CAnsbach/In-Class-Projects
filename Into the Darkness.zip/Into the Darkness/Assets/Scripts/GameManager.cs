﻿/* Made by: Christopher Ansbach
 * Last Modified: 5/2/2019
 * Purpose: This script is used to manage the game.
 *          The script is used to handle events and interaction between the scripts.
 */

using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using UnityEngine;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    public Text displayText;                        //Text object used to display information for the player
    public static GameManager instance;             //Singleton of the GameManager
    RoomController rC;                              //Scripts used in the game
    FloorController fC;
    public PlayerController pC;
    EnemyController eC;
    TextController tC;
    public InputController iC;
    public bool started;                            //Boolean used to detemine if the game started

	void Awake()
    {
        //Singleton
        #region
        if (instance == null)
        {
            instance = this;
        }

        else if (instance != this)
        {
            Destroy(gameObject);
        }

        DontDestroyOnLoad(gameObject);
        #endregion
    }

    void OnEnable()
    {
        pC = GetComponent<PlayerController>();      //Get the scripts
        rC = GetComponent<RoomController>();
        eC = GetComponent<EnemyController>();
        tC = GetComponent<TextController>();
        fC = GetComponent<FloorController>();
        iC = GetComponent<InputController>();

        rC.OnEncounter += BeginEncounter;           //Subscribe the BeginEncounter method to the OnEncounter event

        rC.OnRoomChange += UnpackRoom;              //Subscribe the UnpackRoom method to the OnRoomChange event

        pC.OnEndTurn += MoveMonster;                //Subscribe the MoveMonster method to the OnEndTurn event
        pC.OnEndTurn += StillInEncounter;           //Subscribe the StillInEncounter method to the OnEndTurn event
        pC.OnEndTurn += CheckForEncounters;         //Subscribe the CheckForEncounters method to the OnEndTurn event
        pC.OnEndTurn += CheckSanity;                //Subscribe the CheckSanity method to the OnEndTurn event

        pC.OnHealthChange += UpdateHealthStatus;    //Subscribe the UpdateHealthStatus method to the OnHealthChange event
    }

    private void OnDisable()
    {
        //Unsubscribe the methods
        pC.OnEndTurn -= StillInEncounter;
        pC.OnEndTurn -= MoveMonster;
        pC.OnEndTurn -= CheckForEncounters;
        pC.OnEndTurn -= CheckSanity;

        pC.OnHealthChange -= UpdateHealthStatus;

        rC.OnEncounter -= BeginEncounter;

        rC.OnRoomChange -= UnpackRoom;

    }

    private void Start()
    {
        TypePlay();             //Tell the player to type play to start the game
    }

    /// <summary>
    /// Method used to read saved data
    /// 
    /// </summary>
    public void ReadData()
    {
        //If there is a saved file, load the saved information
        if (File.Exists(Application.persistentDataPath + "/player.save"))
        {
            BinaryFormatter bf = new BinaryFormatter();                                                     //Get a BinaryFormatter
            FileStream file = File.Open(Application.persistentDataPath + "/player.save", FileMode.Open);    //Open the saved file
            SaveState dataToUse = (SaveState)bf.Deserialize(file);                                          //Get the save state
            file.Close();                                                   //Clease the FileStream

            UpdateDisplayTextLoading();                                     //Notify the player that a previous save is being loaded

            fC.LoadSavedFloor(dataToUse.floorIndex, dataToUse.roomIndex);   //Load saved progress
            pC.isInjured = dataToUse.isInjured;                             //Set the health status
            pC.inventory = dataToUse.inventory;                             //Get the saved inventory
            pC.sanity = dataToUse.sanity;                                   //Get the santiy and torch uses
            pC.torchUses = dataToUse.torchUses;
        }

        //Else, give the player a torch, create a save file and unpack the current room
        else
        {
            UpdateDisplayText("No previous save detected. Starting new Game");
            pC.inventory.Add("torch");
            iC.SaveData();
            UnpackRoom();
        }
    }

    /// <summary>
    /// Method used to change floors
    /// 
    /// </summary>
    /// <param name="direction"></param>
    public void GoStairs(string direction)
    {
        pC.GoStairs(direction);             //Call the GoStairs method
    }

    /// <summary>
    /// Method used to update the display text
    /// 
    /// </summary>
    /// <param name="newValue"></param>
    public void UpdateDisplayText(string newValue)
    {
        //Set the display text
        displayText.text = displayText.text + "\n\n" + newValue;
	}

    /// <summary>
    /// Method used to tell the player a previous save is being loaded
    /// 
    /// </summary>
    public void UpdateDisplayTextLoading()
    {
        displayText.text = "Loading previous save..........";
        UpdateDisplayText("If you need help with commands just enter 'help'");
    }

    /// <summary>
    /// Method used to change rooms
    /// 
    /// </summary>
    /// <param name="direction"></param>
    public void Go(string direction)
    {
        pC.Go(direction);               //Call the Go method
    }

    /// <summary>
    /// Method used to get items
    /// 
    /// </summary>
    /// <param name="item"></param>
    public void Get(string item)
    {
        pC.Get(item);           //Call the Get method
    }

    /// <summary>
    /// Method used to unpack the current room
    /// 
    /// </summary>
    public void UnpackRoom()
    {
        UpdateDisplayText(rC.UnpackRoom());     //Return the room's information
    }

    /// <summary>
    /// Method used to start an encounter
    /// 
    /// </summary>
    public void BeginEncounter()
    {
        pC.Encounter(rC.room.hasMonster, rC.room.isTrapped);        //Call the Encounter method
    }

    /// <summary>
    /// Method used to give the PlayerController script the player's encounter choice
    /// 
    /// </summary>
    /// <param name="command"></param>
    /// <param name="direction"></param>
    public void EncounterChoice(string command, string direction)
    {
        pC.choice = command;                //Player's choice
        pC.direction = direction;           //Direction to flee if need be

        //If they are not injured, call the MonsterEncounter method
        if (!pC.isInjured)
        {
            pC.MonsterEncounter();
        }

        //Else, call the InjuredEncounter method
        else
        {
            pC.InjuredEncounter();
        }
    }

    /// <summary>
    /// Method used to start mending
    /// 
    /// </summary>
    public void Mend()
    {
        pC.Mend();          //Call the mend method
    }

    /// <summary>
    /// Method used to handle encounter's with traps
    /// 
    /// </summary>
    /// <param name="command"></param>
    public void EncounterChoiceTrap(string command)
    {
        pC.choice = command;        //The player's choice
        pC.TrapEncounter();         //Start the encounter
    }

    /// <summary>
    /// Method used ot flee
    /// 
    /// </summary>
    /// <param name="direction"></param>
    public void Flee(string direction)
    {
        rC.fleeing = true;          //The player is fleeing
        rC.ChangeRooms(direction);  //Change rooms
    }

    /// <summary>
    /// Method used to return the current room
    /// 
    /// </summary>
    /// <returns></returns>
    public Room GetCurrentRoom()
    {
        return rC.room;         //Return the current room
    }

    /// <summary>
    /// Method used to return the current floor
    /// 
    /// </summary>
    /// <returns></returns>
    public Floor GetCurrentFloor()
    {
        return fC.currentFloor;     //Return the current floor
    }

    /// <summary>
    /// Method used to return to the player's current health status
    /// 
    /// </summary>
    /// <returns></returns>
    public bool GetCurrentHealth()
    {
        return pC.isInjured;
    }

    /// <summary>
    /// Method used to search the room
    /// 
    /// </summary>
    public void Search()
    {
        pC.Search();            //Call the seach method
    }

    /// <summary>
    /// Method used to disarm the trap
    /// 
    /// </summary>
    public void TrapDisarmed()
    {
        rC.room.isTrapped = false;      //Disarm the trap
    }

    /// <summary>
    /// Method used to move the monsters around the room
    /// 
    /// </summary>
    public void MoveMonster()
    {
        eC.MoveMonster();       //Call the MoveMonster method
    }

    /// <summary>
    /// Method used to determine if the player is still in an encounter
    /// 
    /// </summary>
    public void StillInEncounter()
    {
        //If the current room doesn't have a monster, they are not in an encounter
        if (!GetCurrentRoom().hasMonster)
        {
            pC.inEncounter = false;
        }

        //Else, they are
        else
        {
            pC.inEncounter = true;
        }
    }

    /// <summary>
    /// Method used to check if the player is in an encounter
    /// 
    /// </summary>
    public void CheckForEncounters()
    {
        rC.CheckForEncounter();             //Call the CheckForEncounter method
    }

    /// <summary>
    /// Method used to start the game
    /// 
    /// </summary>
    public void StartGame()
    {
        //If the game hasn't started, start it
        if (!started)
        {
            ReadData();             //Read saved data
            UpdateHealthStatus();   //Update the UI elements
            UpdateSanityStatus(); 
            fC.RelockDoors();       //Relock the doors
            started = true;         //The game has started
        }

        //Else, tell the player the game is started
        else
        {
            UpdateDisplayText("Game already started");
        }
    }

    /// <summary>
    /// Method used to end the game at any point during the game
    /// 
    /// </summary>
    public void EndGameLeave()
    {
        UpdateDisplayText("Your fear begins to take over as you are overwhelmed with a need desire to leave.  You run out of the dungeon as fast as you can" +
            " not looking back.\nGAME OVER");   //Notify the player
        pC.gameIsOver = true;           //Game is over
        RestartText();              //Output the restart text
    }

    /// <summary>
    /// Method used to restart the game
    /// 
    /// </summary>
    public void RestartGame()
    {
        displayText.text = "";          //Reset the text
        UpdateDisplayText("Restarting game from previous save");    //Notify the player
        ReadData();                     //Read saved data
        pC.gameIsOver = false;              //Game is not over
        UpdateHealthStatus();           //Update UI elements
        UpdateSanityStatus();
        eC.RemoveCurrentEnemies();      //Remove the enemies from the floors
        fC.RelockDoors();               //Relock the doors
    }

    /// <summary>
    /// Method used to leave in the beginning of the game
    /// 
    /// </summary>
    public void LeaveBeginning()
    {
        UpdateDisplayText("You decide to not enter the dungeon and leave thinking, 'I don't want to die today.'\nGAME OVER");   //Notify the player
        pC.gameIsOver = true;       //Game has to restart
        RestartText();          //Output the restart text
    }

    /// <summary>
    /// Method used to output restart text
    /// 
    /// </summary>
    public void RestartText()
    {
        UpdateDisplayText("Type restart if you wish to restart");       //Output hte text
    }

    /// <summary>
    /// Method to output when the player enters the game
    /// 
    /// </summary>
    public void TypePlay()
    {
        //Output the text
        UpdateDisplayText("Before you were even born there was a sword wielded by a legendary" +
            " knight who roamed the land fighting beasts and scouring dungeons; however, this knight" +
            " became too confident and fought one battle he couldn’t win.  Legends are told of how the" +
            " knight fought and fell to a demon of immense power, and how the sword was taken and kept" +
            " by the demon in the depths of their dungeon.  You grew up listening to these" +
            " legends and spent your life searching for the" +
            " demon’s dungeon in the hopes of finding the sword and destroying the demon, claiming fame" +
            " and glory for yourself.  Today seems to the day that you have you chance to fulfill your dream as you have " +
            "finally found the door to the dungeon.");
        UpdateDisplayText("Type play to start");
    }

    /// <summary>
    /// Method used to update the health status UI element
    /// 
    /// </summary>
    public void UpdateHealthStatus()
    {
        //If the player is dead, set the text to Dead
        if (pC.gameIsOver)
        {
            tC.UpdateHealthStatusText("Dead");
        }

        //Else, if the player is injured, set the text to Injured
        else if (pC.isInjured)
        {
            tC.UpdateHealthStatusText("Injured");
        }

        //Else, the player is healthy
        else
        {
            tC.UpdateHealthStatusText("Healthy");
        }
    }

    /// <summary>
    /// Method used to check the player's sanity level
    /// 
    /// </summary>
    public void CheckSanity()
    {
        pC.Sanity();
        UpdateSanityStatus();       //Update the sanity UI element
    }

    /// <summary>
    /// Method used to update the sanity UI element
    /// 
    /// </summary>
    public void UpdateSanityStatus()
    {
        tC.UpdateSanityStatusText(pC.sanity);       //Update it
    }

    /// <summary>
    /// Method used to get the player's inventory
    /// 
    /// </summary>
    public void GetInventory()
    {
        pC.GetInventory();      //Call the GetInventory method
    }

    /// <summary>
    /// Method used to AddMonsters to the floor
    /// 
    /// </summary>
    public void AddMonsters()
    {
        eC.RemoveCurrentEnemies();          //Remove the current ones
        eC.AddMonsters();                   //Add new ones
    }

    /// <summary>
    /// Method used to allow the player to win the game
    /// 
    /// </summary>
    public void Win()
    {
        pC.gameIsOver = true;           //The game is over
        RestartText();                  //Output the restart text
    }
}
