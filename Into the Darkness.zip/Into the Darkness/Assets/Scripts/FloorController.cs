﻿/* Made by: Christopher Ansbach
 * Last Modified: 5/2/2019
 * Purpose: This script will control the floors of the game.
 *          This script will change what floor is active and the values of the rooms and exits on the floor.
 */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FloorController : MonoBehaviour
{
    public List<Floor> floors;                  //List of floors in the game
    public Floor currentFloor;                  //Current floor
    public RoomController rC;                   //RoomController script

    private void Start()
    {
        rC = GetComponent<RoomController>();    //Get the RoomController script
    }

    /// <summary>
    /// Method used to load saved progress based on the given floor and room indexes
    /// 
    /// </summary>
    /// <param name="floorIndex"></param>
    /// <param name="roomIndex"></param>
    public void LoadSavedFloor(int floorIndex, int roomIndex)
    {
        currentFloor = floors[floorIndex];      //Set the current floor
        SetRooms(roomIndex);                    //Set the current room
    }

    /// <summary>
    /// Method used to set the current room on the floor and give the RoomController script the rooms on the current floor
    /// 
    /// </summary>
    /// <param name="index"></param>
    public void SetRooms(int index)
    {
        rC.rooms = currentFloor.rooms;      //Get the rooms on the floor
        rC.LoadSavedRoom(index);            //Load the saved room
    }

    /// <summary>
    /// Method used to set the current floor
    /// 
    /// </summary>
    /// <param name="floor"></param>
    public void SetCurrentFloor(Floor floor)
    {
        currentFloor = floor;
        SetRooms(0);            //Set the room as well
    }

    /// <summary>
    /// Method used to go through each exit in the game and lock the doors if they should be locked
    /// 
    /// </summary>
    public void RelockDoors()
    {
        foreach(Floor floor in floors)
        {
            for (int i = 0; i < floor.rooms.Count; i++)
            {
                Room room = floor.rooms[i];
                for (int j = 0; j < room.exits.Length; j++)
                {
                    if(room.exits[j].shouldBeLocked)
                    {
                        room.exits[j].isLocked = true;
                    }
                }
            }
        }
    }
}
