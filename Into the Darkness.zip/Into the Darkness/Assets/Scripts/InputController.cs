﻿/* Made by: Christopher Ansbach
 * Last Modified: 5/2/2019
 * Purpose: This script is used to interpret input given to the input field in the game.
 *          The script will add commands, interpret them, and call the necessary methods.
 */

using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using UnityEngine;
using UnityEngine.UI;

public class InputController : MonoBehaviour
{
    public InputField input;                        //InputField to get input from the player
    RoomController rC;                              //RoomController script
    List<string> commands;                          //List of strings to hold the commands
    string[] userStrings;                           //String array to hold the user's input
    public string previousDirection;                //String to hold the player's previous direction (used when fleeing)
    bool isValid;                                   //Boolean to determine if the command is valid

	void Start ()
    {
        rC = GetComponent<RoomController>();            //Get the RoomController script
        input.onEndEdit.AddListener(ProcessInput);      //Add a listener to the onEndEdit event that will call the ProcessInput method
        commands = new List<string>();                  //Create a new list of commands
        commands.Add("go");                             //Add the commands to the list
        commands.Add("get");
        commands.Add("flee");
        commands.Add("fight");
        commands.Add("hide");
        commands.Add("help");
        commands.Add("search");
        commands.Add("disarm");
        commands.Add("mend");
        commands.Add("play");
        commands.Add("leave");
        commands.Add("restart");
        commands.Add("save");
        commands.Add("inventory");
	}
	
    /// <summary>
    /// Method to process the player's input and determine which what to do basaed on the given command
    /// 
    /// </summary>
    /// <param name="userInput"></param>
	void ProcessInput(string userInput)
    {
        isValid = false;                    //Set the boolean
        //If the user gave input, process it
        if (userInput != "")
        {
            userInput = userInput.ToLower();                        //Make the input lowercase
            userStrings = userInput.Split(new char[] { ' ', '.' }); //Split the input for processing

            //For each command in commands, check to see if the first word entered is a command
            foreach(string command in commands)
            {
                //If the first word entered is a command, output the text
                if (userStrings[0] == command && userStrings.Length < 3)
                {
                    GameManager.instance.UpdateDisplayText(userInput);
                    //If the game started, check if the player is dead, if they are process the input
                    if (GameManager.instance.started)
                    {
                        if (!GameManager.instance.pC.gameIsOver)
                        {
                            //Check to see what command was given
                            if (command == "go")
                            {
                                //Check to see if the command has two parts, if it does not tell the player
                                if (userStrings.Length != 2)
                                {
                                    GameManager.instance.UpdateDisplayText("Please provide the command and a direction: go east, go west, etc.");
                                }

                                //Else, determine if the Go method or the GoStairs method should be called
                                else
                                {
                                    //If the player wants to move to another room, use the Go method
                                    if (userStrings[1] != "up" && userStrings[1] != "down")
                                    {
                                        GetPreviousDirection(userStrings[1]);           //Get the previous direction
                                        GameManager.instance.Go(userStrings[1]);
                                    }

                                    //Else, use the GoStairs method and get the previous direction
                                    else
                                    {
                                        GetPreviousDirection(userStrings[1]);
                                        GameManager.instance.GoStairs(userStrings[1]);
                                    }
                                }
                            }

                            //Else if the player wants to get an item, check the input
                            else if (command == "get")
                            {
                                //If the input isn't formatted correctly, tell the player
                                if (userStrings.Length != 2)
                                {
                                    GameManager.instance.UpdateDisplayText("Please provide the command and the item you would like to get: get key, get sword, etc.");
                                }

                                //Else, try to get the item
                                else
                                {
                                    GameManager.instance.Get(userStrings[1]);
                                }
                            }

                            //Else if the input is one word, check which command it is
                            else if (userStrings.Length == 1)
                            {
                                //If the command is to fight or hide, check to see if the room has a monster
                                if (command == "fight" || command == "hide")
                                {
                                    //If it does, call the EncounterChoice method
                                    if (rC.room.hasMonster)
                                    {
                                        GameManager.instance.EncounterChoice(userStrings[0], previousDirection);
                                    }

                                    //Else, notify the player
                                    else
                                    {
                                        GameManager.instance.UpdateDisplayText("There is nothing to fight or hide from.");
                                    }
                                }

                                //Else if the command is to flee, check if there is a monster
                                else if (command == "flee")
                                {
                                    //If the room has a monster, call the EncounterChoice method and get the previous direction
                                    if (rC.room.hasMonster)
                                    {
                                        GameManager.instance.EncounterChoice(userStrings[0], previousDirection);
                                        GetPreviousDirection(previousDirection);
                                    }

                                    //Else, notify the player
                                    else
                                    {
                                        GameManager.instance.UpdateDisplayText("There is nothing to flee from.");
                                    }
                                }

                                //Else if the command is help, output the help menu
                                else if (command == "help")
                                {
                                    PrintHelpMenu();
                                }

                                //Else if the command is to search, search the room
                                else if (command == "search")
                                {
                                    GameManager.instance.Search();
                                }

                                //Else if the command is to disarm, check if the room is trapped
                                else if (command == "disarm")
                                {

                                    //If it is, disarm the trap
                                    if (rC.room.isTrapped)
                                    {
                                        GameManager.instance.EncounterChoiceTrap(userStrings[0]);
                                    }

                                    //Else, tell the player the room is not trapped
                                    else
                                    {
                                        GameManager.instance.UpdateDisplayText("The room is not trapped.");
                                    }
                                }

                                //Else if the command is to mend, attempt to mend
                                else if (command == "mend")
                                {
                                    GameManager.instance.Mend();
                                }

                                //Else if the command is to play, the game is already started
                                else if (command == "play")
                                {
                                    GameManager.instance.UpdateDisplayText("The game is already started.");
                                }

                                //Else if the command is to leave, determine which room they are in
                                else if (command == "leave")
                                {
                                    //If they are outside, call the LeaveBeginning method
                                    if (GameManager.instance.GetCurrentRoom().roomName == "Outside")
                                    {
                                        GameManager.instance.LeaveBeginning();
                                    }

                                    //Else, call the EndGameLeave method
                                    else
                                    {
                                        GameManager.instance.EndGameLeave();
                                    }
                                }

                                //Else if the command is to restart, restart the game
                                else if (command == "restart")
                                {
                                    GameManager.instance.RestartGame();
                                }

                                //Else if the command is to save, save the game
                                else if (command == "save")
                                {
                                    GameManager.instance.UpdateDisplayText("Saving Data");
                                    SaveData();
                                }

                                //Else if the command is inventory, return the player's current inventory
                                else if (command == "inventory")
                                {
                                    GameManager.instance.GetInventory();
                                }
                            }
                        }

                        //Else, check if they are attempting to restart
                        else
                        {
                            //If they are, restart
                            if (command == "restart")
                            {
                                GameManager.instance.RestartGame();
                            }

                            //Else, let them know the game ended
                            else
                            {
                                GameManager.instance.UpdateDisplayText("The game ended. Please enter restart if you wish to restart the game.");
                            }
                        }
                    }

                    //Else, check if the player wants to play the game or get the help menu
                    else
                    {
                        //If they want to play, start the game
                        if (command == "play")
                        {
                            GameManager.instance.StartGame();
                        }

                        //Else if they want help, print the help menu
                        else if (command == "help")
                        {
                            PrintHelpMenu();
                            GameManager.instance.TypePlay();
                        }

                        //Else, let them know the game hasn't started
                        else
                        {
                            GameManager.instance.UpdateDisplayText("Please enter either play to start the game or help to see the commands.");
                        }
                    }

                    isValid = true; //The player input a valid command
                }
            }

            //If the command is not valid, let the player know
            if (!isValid)
            {
                GameManager.instance.UpdateDisplayText("Invalid Input.  For a list of commands enter help.");
            }

            input.text = "";                //Reset the text
            input.ActivateInputField();     //Activate the InputField
        }
    }

    /// <summary>
    /// Method used to the current game's data
    /// 
    /// </summary>
    public void SaveData()
    {
        SaveState update = new SaveState();                                     //Create a new save state
        update.roomIndex = GameManager.instance.GetCurrentRoom().index;         //Get the room index
        update.floorIndex = GameManager.instance.GetCurrentFloor().index;       //Get the floor index
        update.isInjured = GameManager.instance.GetCurrentHealth();             //Get the player's health status
        update.inventory = new List<string>();                                  //Create a new string list
        update.inventory = GameManager.instance.pC.inventory;                   //Get the player's current inventory
        update.sanity = GameManager.instance.pC.sanity;                         //Get the player's sanity
        update.torchUses = GameManager.instance.pC.torchUses;                   //Get the palyer's torch uses

        BinaryFormatter bf = new BinaryFormatter();                                             //Create a new BinaryFormatter 
        FileStream fileStream = File.Create(Application.persistentDataPath + "/player.save");   //Create a new FileStream and make a new file at the given location
        bf.Serialize(fileStream, update);                                                       //Serialize the data to the given location 
        fileStream.Close();                                                                     //Close the FileSteam
    }

    /// <summary>
    /// Method used to read the saved data
    /// 
    /// </summary>
    void ReadData()
    {
        GameManager.instance.ReadData();    //Call the ReadData method
    }

    /// <summary>
    /// Method used to output a formatted help menu that tells what the commands are and what they do
    /// 
    /// </summary>
    void PrintHelpMenu()
    {
        GameManager.instance.UpdateDisplayText("There are a total of " + commands.Count + " commands in this game.\n" +
        "They include:\n\thelp - Opens this menu.\n\tplay - start the game.\n\tsave - Save current game.\n\trestart - Restart" +
        " the current game from a previous save or from the beginning.\n\tgo - Used to traverse the rooms in the game." +
        "\n\tMust be given the command and a direction (go north).\n\tget - Used to add items to your inventory." +
        "\n\tMust be given the name of the item along with the command (get key).\n\tinventory - Lists the items in your current inventory.\n\tsearch - Search the current room for any" +
        "useful items and/or traps.\n\tmend - if you have bandages you heal instantly; however, " +
        "if you don't heal after a period of time\n\tleave - leave the dungeon (ends the game)\n\nThe following commands are used " +
        "in encounters (trap or monster):\n\tfight - Attempt to fight the monster.\n\tflee - Run back to the previous room.\n\thide" +
        " - attempt to hide from the monster.\n\tdisarm - Attempt to disarm the trap.");
    }

    /// <summary>
    /// Method used to get the previous direction based on the given string
    /// </summary>
    /// <param name="direction"></param>
    void GetPreviousDirection(string direction)
    {
        //Determine what the previous direction is based on what the given string is
        if (direction == "north")
        {
            previousDirection = "south";
        }

        else if (direction == "south")
        {
            previousDirection = "north";
        }
        else if (direction == "east")
        {
            previousDirection = "west";
        }
        else if (direction == "west")
        {
            previousDirection = "east";
        }
        else if (direction == "up")
        {
            previousDirection = "down";
        }
        else if (direction == "down")
        {
            previousDirection = "up";
        }
    }
}