﻿/* Made by: Christopher Ansbach
 * Last Modified: 5/2/2019
 * Purpose: This is the Exit scriptable object.
 */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Text/Exit")]

public class Exit : ScriptableObject
{
    public bool isLocked, shouldBeLocked;               //Determine if the exit is locked, and should be locked.
    public enum Direction { north, south, east, west }; //Possible direction for the exit
    public Direction theDirection;                      //Direction the exit is in
    [TextArea] public string description;               //Description of the exit
    public Room room;                                   //Room the exit leads to
}
