﻿/* Made by: Christopher Ansbach
 * Last Modified: 5/2/2019
 * Purpose: This is a serializable class used to create a save state to save the player's progress.
 */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;


[System.Serializable]
public class SaveState
{
    //Information to save
    public int roomIndex, floorIndex, sanity, torchUses;        //Room and floor indexes as well as the player's sanity and torch uses left
    public bool isInjured;                                      //Save the injured status
    public List<string> inventory;                              //Save the player's inventory
}
