﻿/* Made by: Christopher Ansbach
 * Last Modified: 5/2/2019
 * Purpose: This script is used to perform commands done by the player as well as change values associated with the player.
 *          Encounters with monsters, injuries, death, and other aspects and events the player has and can do are done here.
 */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public bool isInjured, gameIsOver, inEncounter, wasTrapped;         //Booleans to check is the player is injured, dead, in an encounter, as well as if the room was trapped
    public string choice, direction;            //String that holds the player's choice and the direction they choose (if they choose one)
    public int sanity = 10, torchUses = 5;      //Integers to hold the player's sanity and torch uses
    public List<string> inventory;              //List of strings to hold the player's inventory
    public delegate void EndTurn();             //Delegates to make events
    public delegate void TakeDamage();
    public event EndTurn OnEndTurn;             //Event to start when a turn ends
    public event TakeDamage OnHealthChange;     //Event to start when the player's health changes
    RoomController rC;                          //RoomController script
    Enemy encounteredMonster;                   //Enemy that the player encountered
    string inventoryItems;                      //String that hold the items in the player's inventory (returned to the player)

    private void Start()
    {
        //If the inventory is null, make a new list
        if (inventory == null)
        {
            inventory = new List<string>();
        }

        rC = GetComponent<RoomController>();        //Get the RoomController script
    }

    /// <summary>
    /// Method used to move the player around the rooms in the given direction
    /// 
    /// </summary>
    /// <param name="direction"></param>
    public void Go(string direction)
    {
        //If they are not in an ecounter, they can move
        if (!inEncounter)
        {
            //If the room they are in is trapped and they are not injured, injure them
            if (rC.room.isTrapped && !isInjured)
            {
                //isInjured = true;
                Injure();               //Injure the player
                GameManager.instance.UpdateDisplayText("When you step out of the door to the next room you are injured by a bear trap.");   //Notify the player
                rC.room.isTrapped = wasTrapped;     //The room was trapped
                wasTrapped = false;                 //Reset the wasTrapped boolean
                rC.ChangeRooms(direction);          //Change the room
                //HealthChange();
            }

            //Else if the room is trapped and the player is injured, kill the player
            else if (rC.room.isTrapped && isInjured)
            {
                GameManager.instance.UpdateDisplayText("As you are leaving the room you are killed by a bear trap.");
                Injure();           //Call the method
                //isDead = true;
                //HealthChange();
                //GameManager.instance.RestartText();
            }

            //Else, change the room
            else
            {
                rC.room.isTrapped = wasTrapped;     //Set the trap again if needed
                wasTrapped = false;                 //Reset the boolean
                rC.ChangeRooms(direction);          //Change rooms
            }

            //End turn
            EndPlayerTurn();
        }

        //Else, the player is in an encounter
        else
        {
            InEncounter();
        }
    }

    /// <summary>
    /// Method used when the player wants to move to a different floor
    /// 
    /// </summary>
    /// <param name="direction"></param>
    public void GoStairs(string direction)
    {
        //If the player is not in an encounter, change floors and add monsters
        if (!inEncounter)
        {
            rC.ChangeFloors(direction);
            GameManager.instance.AddMonsters();
        }
    }

    /// <summary>
    /// Method used to search the room for items and traps
    /// 
    /// </summary>
    public void Search()
    {
        //If the player is not in an encounter, search the room
        if (!inEncounter)
        {
            Result("Searching the room you find:\n\t" + rC.GetItems());         //Return info about items
            //If the room is trapped, notify the player.
            if (rC.room.isTrapped)
            {
                Result("You find a trap on the doors that will trigger if you try to leave the room.");
            }
        }

        //Else, the player is in an encounter
        else
        {
            InEncounter();
        }
    }

    /// <summary>
    /// Method used to get items from the room
    /// 
    /// </summary>
    /// <param name="item"></param>
    public void Get(string item)
    {
        //If the player is not in an encounter, try to ge the item
        if (!inEncounter)
        {
            //If the item is in the room, check if the player currently has the item
            if (rC.PickUpItem(item))
            {
                //If the player has the item, don't add it
                if (inventory.Contains(item))
                {
                    Result("You already have one of those.");
                }

                //Else, add the item and notify the player.
                else
                {
                    AddToInventory(item);
                    Result("You pick up the " + item + ".");
                }
            }

            //Else, tell the player that the item is not in the room
            else
            {
                GameManager.instance.UpdateDisplayText("There is no " + item + " in this room.");
            }
        }

        //Else, the player is in an encounter
        else
        {
            InEncounter();
        }
    }

    /// <summary>
    /// Method used to start an encounter based on whether it is a monster or a trap
    /// 
    /// </summary>
    /// <param name="monster"></param>
    /// <param name="trap"></param>
    public void Encounter(bool monster, bool trap)
    {
        //If the encounter is with a monster, get the monster encountered and notify the player
        if (monster)
        {
            encounteredMonster = rC.room.monsters[0];
            Result("As you enter the room you hear footsteps nearby.  It doesn't take you long before you can determine" +
                " what they are from.....A monster. As it gets closer it sounds like it is a " + encounteredMonster.enemyName + ".");
            inEncounter = true;         //They are currently in an encounter
        }

        //Else if it is a trap, the room was trapped
        else if (trap)
        {
            wasTrapped = true;
        }
    }

    /// <summary>
    /// Method used to heal the player
    /// 
    /// </summary>
    public void Mend()
    {
        //If the player is not in an encounter, check if the player is injured
        if (!inEncounter)
        {
            //If the player is injured figure out is the player is mending with bandages or time
            if (isInjured)
            {
                //If the player is healing with bandages, heal the player and end their turn
                if(inventory.Contains("bandages"))
                {
                    Result("You use the bandages you have to mend your wounds.");
                    isInjured = false;
                    inventory.Remove("bandages");
                    HealthChange();
                    EndPlayerTurn();
                }

                //Else, the healing will take place over two turns
                else
                {
                    Result("You take some time to mend your wounds.");
                    EndPlayerTurn();

                    //If the player encounters something during the mending process, flee in a random direction
                    if (inEncounter)
                    {
                        direction = GameManager.instance.GetCurrentRoom().exits[Random.Range(0, GameManager.instance.GetCurrentRoom().exits.Length)].theDirection.ToString();
                        Flee();
                    }

                    //Else, they successfully healed over time
                    else
                    {
                        Result("You have successfully mended your wounds");
                        isInjured = false;
                        HealthChange();
                        EndPlayerTurn();
                    }
                }
            }

            //Else, the player is not injured
            else
            {
                Result("You are not injured.");
            }
        }

        //Else, the player is in an encounter
        else
        {
            InEncounter();
        }
    }

    /// <summary>
    /// Method to control the monster encounter
    /// 
    /// </summary>
    public void MonsterEncounter()
    {
        //If the player's choice is to flee, flee
        if (choice == "flee")
        {
            Result("As the foot steps approach the room getting louder and louder you decide to flee " + direction);
            Flee();
        }

        //Else if the player chooses to fight, check for weapons and their types
        else if (choice == "fight")
        {
            Result("You prepare to fight the monster as the footsteps get louder.");

            //Else if, the player has smitemourne (the legendary sword), kill the mosnter and don't remove the blade
            if (inventory.Contains("smitemourne"))
            {
                Result("As you take out the legendary sword a look of fear come across the monster's face; however, before it can run you" +
                    " cut it down in one hit.");
                KillMonster();
            }

            //If the player has a sword, check if the monster is legendary
            else if (inventory.Contains("sword"))
            {
                //If the monster is legendary, the monster does not die and the player is injured and flees
                if (encounteredMonster.legendary)
                {
                    Result("While engaging the " + encounteredMonster.enemyName + " you notice that there is something special about them. As you strike out at them they deftly parry you and break your sword." +
                        " They then counter and injure you. You are forced to flee and think to yourself that you need a better weapon than swords or maces.");
                    Injure();
                    Flee();
                }

                //Else, the monster is defeated
                else
                {
                    Result("You grab you sword and fight the monster.  You defeat the monster; however, your sword is now damaged beyond repair." +
                    "  You decide to drop the sword a take a short rest to recover.");
                    KillMonster();
                }

                //The sword is broken
                inventory.Remove("sword");
            }

            //Else if the inventory has a mace, treat it the same was as the sword
            else if (inventory.Contains("mace"))
            {
                if (encounteredMonster.legendary)
                {
                    Result("While engaging the " + encounteredMonster.enemyName + " you notice that there is something special about them. As you strike out at them they deftly parry you and break your mace." +
                        " They then counter and injure you. You are forced to flee and think to yourself that you need a better weapon than swords or maces.");
                    Injure();
                    Flee();
                }

                else
                {
                    Result("You grab you sword and fight the monster.  You defeat the monster; however, your sword is now damaged beyond repair." +
                    "  You decide to drop the sword a take a short rest to recover.");
                    KillMonster();
                }

                inventory.Remove("mace");
            }

            //Else, the player has no weapon to fight and get injured and flees
            else
            {
                Result("You attempt to fight the monster as it enters the room; however, you are injured and forced to flee " + direction + ".  You think" +
                    " to yourself that it may be best to have a weapon before trying to fight another monster");
                Injure();
                Flee();
            }

            //The player is no longer in an encounter
            inEncounter = false;
        }

        //Else if the player chooses to hide, check to see if the encountered monster is perceptive
        else if (choice == "hide")
        {
            Result("You decide to attempt to hide from the monster before it enters the room.");
            Result("You take cover behind some nearby boxes.");

            //If the monster is perceptive, injure the player
            if(encounteredMonster.perceptive)
            {
                Result("You try to hide but the " + encounteredMonster.enemyName + " spots you behind the boxes and attacks.  You are " +
                    "forced to flee to the previous room.");
                Injure();

                //If the player is not dead, they flee
                if (!gameIsOver)
                {
                    Flee();
                }
            }

            //Else, they hide successfully
            else
            {
                Result("After searching the room for what feels like an hour, the " + encounteredMonster.enemyName + " decides to leave.");
            }

            //If they are not dead, end their turn
            if (!gameIsOver)
            {
                EndPlayerTurn();
            }
        }
    }

    /// <summary>
    /// Method used to handle a trap encounter
    /// 
    /// </summary>
    public void TrapEncounter()
    {
        //If they choose to disarm it, disarm the trap
        if (choice == "disarm")
        {
            Result("You attempt to disarm the trap.......");
            Result("You are successful.");
            GameManager.instance.TrapDisarmed();
        }
    }

    /// <summary>
    /// Method used to add an item to te player's inventory
    /// 
    /// </summary>
    /// <param name="item"></param>
    public void AddToInventory(string item)
    {
        inventory.Add(item);        //Add the item to the inventory
    }
    
    /// <summary>
    /// Method used to inform the player about the results of their choices
    /// 
    /// </summary>
    /// <param name="result"></param>
    void Result(string result)
    {
        GameManager.instance.UpdateDisplayText(result);     //Update the display text
    }

    /// <summary>
    /// Method used to injure the player
    /// 
    /// </summary>
    void Injure()
    {
        //If the are uninjured, injure them
        if (!isInjured)
        {
            isInjured = true;
            HealthChange();
        }

        //Else, kill them
        else
        {
            Result("As you are injured again you take one final breath as you fall to the floor of the dungeon.\n\nGAME OVER");
            gameIsOver = true;
            HealthChange();
            GameManager.instance.RestartText();
        }
    }

    /// <summary>
    /// Method used to start the OnHealthChange event
    /// 
    /// </summary>
    void HealthChange()
    {
        if (OnHealthChange != null)
        {
            OnHealthChange();
        }
    }

    /// <summary>
    /// Method used to have the player flee
    /// 
    /// </summary>
    void Flee()
    {
        inEncounter = false;                            //The player is no longer in an encounter
        Result("You flee " + direction + ".");          //Notify the player

        //If the player is not fleeing up or down, then use the Go method
        if (direction != "up" || direction != "down")
        {
            Go(direction);
        }

        //Else, use the GoStairs method
        else
        {
            GoStairs(direction);
        }
    }

    /// <summary>
    /// Method used to kill the monster
    /// 
    /// </summary>
    void KillMonster()
    {
        rC.room.monsters.Remove(encounteredMonster);        //Remove the monster
        rC.room.hasMonster = false;                         //The room no longer has a monster
    }

    /// <summary>
    /// Method used to end the player's turn by calling the OnEndTurn event
    /// 
    /// </summary>
    public void EndPlayerTurn()
    {
        if (OnEndTurn != null)
        {
            OnEndTurn();
        }
    }

    /// <summary>
    /// Method used to notify the player that they are in an event
    /// 
    /// </summary>
    void InEncounter()
    {
        GameManager.instance.UpdateDisplayText("You are currently in an encounter with a monster.  Choose from the commands: fight, flee, or hide.");
    }

    /// <summary>
    /// Method used when the player enters an encounter while injured
    /// 
    /// If they are injured, they can only hide
    /// </summary>
    public void InjuredEncounter()
    {
        //If they choose something other than hide, notify them that they have to hide
        if (choice != "hide")
        {
            Result("You think about " + choice + "ing; however, you feel that you are not in the state to run or fight and so you decide to hide.");
        }
        //Set choice to hide and start the encounter
        choice = "hide";
        MonsterEncounter();
    }

    /// <summary>
    /// Method used to manage the player's sanity
    /// 
    /// </summary>
    public void Sanity()
    {
        //If the player has a torch, they regain sanity if they have less than 10 and loose torch uses
        if (inventory.Contains("torch"))
        {
            if (sanity < 10)
            {
                sanity++;
            }
            torchUses--;
        }

        //Else if their sanity is 0, they loose their sanity and the game ends
        else if (sanity == 0)
        {
            Result("You begin to loose your grip on reality and descend into madness. GAME OVER");
            gameIsOver = true;
            HealthChange();
            GameManager.instance.RestartText();
        }

        //Else, the player looses sanity
        else
        {
            Result("Continuing without a torch, you can feel yourself losing your sanity.");
            sanity--;
        }

        //If the player's torch uses is 0, the torch burns out and is removed and the torch uses gets reset
        if (torchUses == 0)
        {
            inventory.Remove("torch");
            Result("Your torch burns out");
            torchUses = 5;
        }
    }

    /// <summary>
    /// Method used to return information about the player's current inventory
    /// 
    /// </summary>
    public void GetInventory()
    {
        //For loop to go through each item in the player's inventory
        for (int i = 0; i < inventory.Count; i ++)
        {
            //Conditions to format the string to give the player
            if (i < inventory.Count - 1)
            {
                inventoryItems += inventory[i] + ", ";
            }

            else
            {
                inventoryItems += inventory[i] + ".";
            }
        }

        //Show the information to the player
        Result("Items in inventory:\n\t" + inventoryItems);
    }
}
